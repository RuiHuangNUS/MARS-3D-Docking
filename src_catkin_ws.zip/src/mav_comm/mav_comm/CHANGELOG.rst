^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package mav_comm
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
3.3.3 (2019-08-16)
------------------
* Add 6DOF trajectory compatibility.
* See mav_msgs and mav_planning_msgs changelogs for details.

3.3.2 (2018-08-22)
------------------
* Fix indigo eigen3 compatibility.

3.3.1 (2018-08-21)
------------------
* Change maintainer.
* Add dependencies, see planning_msgs changelog for details.

3.3.0 (2018-08-17)
------------------
* More utilities and lower level UAV kinematics, see mav_msgs changelog for details.
* 2D polygon planning msgs, see planings_msgs changelog for details.

3.1.0 (2016-12-01)
------------------
* More helper functions, see mav_msgs changelog for details.

3.0.0 (2015-08-09)
------------------
* Changed API for mav_msgs, see mav_msgs changelog for details.

2.0.3 (2015-05-22)
------------------
